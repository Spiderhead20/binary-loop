﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Line : MonoBehaviour
{
    //Script to control the rotation behavior of each line obstacle
    public float speed;
    float angle;
    void Start()
    {
        angle = Random.Range(-90, 90); //random angle to generate more diversity
        transform.localEulerAngles = new Vector3(0, 0, angle);
    }
    void Update()
    {
        angle += speed * Time.deltaTime; //It just keeps rotating
        transform.localEulerAngles = new Vector3(0, 0, angle);
    }
}
