﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    //Main player behavior script
    Vector3 InitPos;
    public GameObject lvr, particles, camera;
    public float speed,jumpAmount;
    float xAxis, jumpForce, initialJump, limit;
    Rigidbody2D rb;
    Animator animator;
    GameObject[] invisible; //to keep track of collisions to ignore
    GameObject[] momentary; //to keep track of collisions to ignore in a certain moment
    public GameObject[] boxes;
    bool jump = false, jumping = false, lever = false;
    void Start()
    {
        invisible = GameObject.FindGameObjectsWithTag("Invisible");
        momentary = GameObject.FindGameObjectsWithTag("Momentary");
        for (int i = 0; i < invisible.Length; i++)
            Physics2D.IgnoreCollision(GetComponent<PolygonCollider2D>(), invisible[i].GetComponent<BoxCollider2D>());
        InitPos = transform.position;
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }
    void Update()
    {
        transform.localEulerAngles = new Vector3(0, 0, 0);
        xAxis = Input.GetAxis("Horizontal"); //Major movement scripting
        if (xAxis != 0)
        {
            if(xAxis < 0)
                animator.SetTrigger("WalkBack");
            else
                animator.SetTrigger("Walk");
        }
        else
        {
            animator.SetTrigger("Iddle");
        }
        if (Input.GetKeyDown("space") && jump) //Sets the jumping stage if the player its on the ground
        {
            FindObjectOfType<AudioManager>().Play("Jump");
            jumpForce = 1;
            initialJump = transform.position.y;
            jump = false;
            jumping = true;
            limit = 1.7f;
        }
        if(jumping && transform.position.y >= initialJump + limit) //Once the player reaches a certain heigh, it goes down
        {
            jumping = false;
            jumpForce = 0;
        }
        if (lever)
            if (Input.GetKeyDown("z")) //Dtermines if player activates lever
            {
                lvr.GetComponent<Animator>().SetTrigger("On");
                FindObjectOfType<AudioManager>().Play("Switch");
                if (lvr.GetComponent<BreakLoop>().type)
                    for (int i = 0; i < momentary.Length; i++)
                    {
                        Physics2D.IgnoreCollision(GetComponent<PolygonCollider2D>(), momentary[i].GetComponent<BoxCollider2D>());
                        for(int j = 0; j < boxes.Length; j++)
                            Physics2D.IgnoreCollision(boxes[j].GetComponent<BoxCollider2D>(), momentary[i].GetComponent<BoxCollider2D>());
                    }
            }
    }
    public void WalkSound() //function called via animator
    {
        if (!jumping)
        {
            float pitch = Random.Range(.4f, 1.6f); //adds randomness to the walk sound
            FindObjectOfType<AudioManager>().GetComponent<AudioManager>().sounds[1].pitch = pitch;
            FindObjectOfType<AudioManager>().Play("Walk");
        }
    }
    private void FixedUpdate()
    {
        rb.velocity = new Vector2(xAxis * speed * Time.fixedDeltaTime, jumpForce * jumpAmount * Time.fixedDeltaTime); //fixed behavior of the player
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.CompareTag("Ground"))
            jump = true;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.transform.CompareTag("Binary")) //Binary tag stands for every obstacle
        {
            GameObject part = Instantiate(particles, transform.position, Quaternion.identity);
            Destroy(part, 1f);
            transform.position = InitPos;
            if (collision.transform.parent.GetComponent<BinaryMovement>())
            {
                collision.transform.parent.position = collision.transform.parent.GetComponent<BinaryMovement>().InitPos;
                collision.transform.parent.localEulerAngles = new Vector3(0, 0, 0);
            }
            FindObjectOfType<AudioManager>().Play("Destroy");
            camera.GetComponent<Animator>().SetTrigger("Shake");
            jumping = false;
            jumpForce = 0;
        }
        if (collision.transform.CompareTag("Switch"))
        {
            lever = true;
            lvr = collision.gameObject;
        }
        if (collision.transform.CompareTag("Jump")) //Jump tag stands for every jumper help
        {
            FindObjectOfType<AudioManager>().Play("Jump");
            collision.GetComponent<Animator>().SetTrigger("On");
            jumpForce = 1;
            initialJump = transform.position.y;
            jump = false;
            jumping = true;
            limit = 6;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.transform.CompareTag("Switch"))
            lever = false;
    }
}
