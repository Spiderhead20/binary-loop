﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spikes : MonoBehaviour
{
    //Script to deploy spikes as if they were bullets
    public GameObject spike;
    public float spikeForce, timing; //timing sets the fire cadency and spikeForce sets the speed of the spike
    float timer = 0;
    void Update()
    {
        timer += Time.deltaTime;
        if(timer >= timing)
        {
            timer = 0;
            ShootSpike();
        }
    }
    void ShootSpike()
    {
        GameObject sp = Instantiate(spike, transform.position, transform.rotation);
        Rigidbody2D rb = sp.GetComponent<Rigidbody2D>();
        rb.AddForce(transform.up * spikeForce, ForceMode2D.Impulse);
        sp.transform.parent = gameObject.transform; //For reasons of the player script, every spike type of object must be a child
        Destroy(sp, 8); //to avoid performance issues and to save making another script, each spike destroys after 8 secs
    }
}
