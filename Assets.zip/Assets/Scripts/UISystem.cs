﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UISystem : MonoBehaviour
{
    //Keeps register of each level completed, manages the input of every button and the change of every scene
    public GameObject b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12;
    public GameObject Pause, Finish;
    bool end = false;
    static bool l1 = false, l2 = false, l3 = false, l4 = false, l5 = false, l6 = false, l7 = false, l8 = false, l9 = false, l10 = false, l11 = false, l12 = false;
    private void Start()
    {
        int curentScene = SceneManager.GetActiveScene().buildIndex;
        if (curentScene == 0)
        {
            if (l2)
                b2.SetActive(true);
            if (l3)
                b3.SetActive(true);
            if (l4)
                b4.SetActive(true);
            if (l5)
                b5.SetActive(true);
            if (l6)
                b6.SetActive(true);
            if (l7)
                b7.SetActive(true);
            if (l8)
                b8.SetActive(true);
            if (l9)
                b9.SetActive(true);
            if (l10)
                b10.SetActive(true);
            if (l11)
                b11.SetActive(true);
            if (l12)
                b12.SetActive(true);
        }
    }
    void Update()
    {
        if (Input.GetKey(KeyCode.Escape) && !end)
        {
            Pause.SetActive(true);
            Time.timeScale = 0;
        }
    }
    public void ResumeGame()
    {
        Pause.SetActive(false);
        FindObjectOfType<AudioManager>().Play("Button");
        Time.timeScale = 1;
    }
    public void RetryLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        FindObjectOfType<AudioManager>().Play("Button");
        Time.timeScale = 1;
    }
    public void LoopEnd()
    {
        int curentScene = SceneManager.GetActiveScene().buildIndex + 1;
        switch (curentScene)
        {
            case 2:
                l2 = true;
                break;
            case 3:
                l3 = true;
                break;
            case 4:
                l4 = true;
                break;
            case 5:
                l5 = true;
                break;
            case 6:
                l6 = true;
                break;
            case 7:
                l7 = true;
                break;
            case 8:
                l8 = true;
                break;
            case 9:
                l9 = true;
                break;
            case 10:
                l10 = true;
                break;
            case 11:
                l11 = true;
                break;
            case 12:
                l12 = true;
                break;
        }
        Finish.SetActive(true);
        end = true;
    }
    public void NextLevel()
    {
        int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene(nextSceneIndex);
    }
    public void MainMenu()
    {
        SceneManager.LoadScene("Menu");
        FindObjectOfType<AudioManager>().Play("Button");
        Time.timeScale = 1;
    }
    public void Level1()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 1");
    }
    public void Level2()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 2");
    }
    public void Level3()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 3");
    }
    public void Level4()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 4");
    }
    public void Level5()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 5");
    }
    public void Level6()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 6");
    }
    public void Level7()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 7");
    }
    public void Level8()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 8");
    }
    public void Level9()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 9");
    }
    public void Level10()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 10");
    }
    public void Level11()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 11");
    }
    public void Level12()
    {
        FindObjectOfType<AudioManager>().Play("Button");
        SceneManager.LoadScene("Level 12");
    }

}
