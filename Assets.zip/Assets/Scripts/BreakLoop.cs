﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BreakLoop : MonoBehaviour
{
    //This is called everytime a lever is activated
    public GameObject platform;
    public UISystem uISystem;
    public bool type; //Determines if we are working with a final lever or not
    void SecretPlatform()
    {
        if (!type) //if it is indeed final, the level finished
        {
            platform.GetComponent<Animator>().SetTrigger("On");
            uISystem.LoopEnd();
            FindObjectOfType<AudioManager>().Play("Break");
        }
        else
        {
            platform.GetComponent<Animator>().SetTrigger("Off");
            FindObjectOfType<AudioManager>().Play("Break");
        }
    }
}
