﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BinaryParallax : MonoBehaviour
{
    //Script to add parallax effect to the background
    public float speed;
    void Update()
    {
       transform.Translate(Vector2.left * speed * Time.deltaTime);
        if(transform.position.x <= -20.4837f) //20.4837 its the size of the xbounds of the used script
        {
            transform.position = new Vector3(20.4837f, transform.position.y, 0);
        }
    }
}
