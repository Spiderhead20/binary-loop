﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BinaryMovement : MonoBehaviour
{
    //Main behavior of the enemy
    public BoxCollider2D[] stuff;
    public float speedForce, jumpAmount;
    Rigidbody2D rb;
    public Vector3 InitPos;
    bool reverse = true, jumping; //tags to determine if the enemy should jump or change direction
    float timer, jumpForce = 0, limit = 3, initialJump;
    void Start()
    {
        InitPos = transform.position;
        rb = GetComponent<Rigidbody2D>();
        GameObject robot = GameObject.Find("Robot");
        Physics2D.IgnoreCollision(robot.GetComponent<PolygonCollider2D>(), GetComponent<BoxCollider2D>());
        for(int i = 0; i < stuff.Length; i++)
            Physics2D.IgnoreCollision(stuff[i], GetComponent<BoxCollider2D>());
    }
    private void Update()
    {
        if (!reverse) //timer to prevent being stuck in a wall
            timer += Time.deltaTime;
        if (timer >= .3)
            reverse = true;
        transform.localEulerAngles = new Vector3(0, 0, 0); //prevents clunky rotations
        if (jumping && transform.position.y >= initialJump + limit)
        {
            jumping = false;
            jumpForce = 0;
        }
    }
    void FixedUpdate()
    {
        rb.velocity = new Vector2(speedForce * Time.deltaTime, jumpForce * jumpAmount * Time.fixedDeltaTime);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Barrier")) //Tag to determine if the enemy should stop
            speedForce = 0;
        if (collision.gameObject.CompareTag("Reverse") && reverse)
        {
            speedForce = speedForce * -1;
            reverse = false;
            timer = 0;
        }
        if (collision.transform.CompareTag("Jump")) //As same as the player jump tag
        {
            FindObjectOfType<AudioManager>().Play("Jump");
            collision.GetComponent<Animator>().SetTrigger("On");
            jumpForce = 1;
            initialJump = transform.position.y;
            jumping = true;
            limit = 5;
        }
    }
}
