﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Loop : MonoBehaviour
{
    //Every object capable of crossing the loop must contain the script
    public Transform exit, entry;
    public bool binary, box; //Binary its for the enemy, box for other objects
    void Update()
    {
        if (transform.position.x >= exit.position.x)
        {
            if (binary)
                GetComponent<BinaryMovement>().speedForce += 20;
            if(box)
                transform.position = new Vector3(entry.position.x + 1.5f, entry.position.y, 0);
            else
            transform.position = new Vector3(entry.position.x + .5f, entry.position.y, 0);
            FindObjectOfType<AudioManager>().Play("Loop");
        }
        if (transform.position.x <= entry.position.x)
        {
            if (box)
                transform.position = new Vector3(exit.position.x - 1.5f, exit.position.y, 0);
            else
                transform.position = new Vector3(exit.position.x - .5f, exit.position.y, 0);
            FindObjectOfType<AudioManager>().Play("Loop");
        }
    }
}
